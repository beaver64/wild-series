<?php

// src/Controller/WildController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/wild", name="wild")
 */
Class WildController extends AbstractController
{
    /**
     * @Route("/", name="wild_index")
     */
    public function index()
    {
        return $this->render('Wild/index.html.twig', [
            'website' => 'Wild Séries',
        ]);
    }
    /**
     * @Route("/show/{title}", name="wild_show", requirements={"title"="[a-z0-9/-]+"}
     */
    public function show(string $title)
    {
        return $this->render(Wild/show.html.twig, [
            "titles"=>$title,
        ]);
    }
}